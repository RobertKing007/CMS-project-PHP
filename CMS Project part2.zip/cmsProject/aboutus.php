<?php
ob_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<link rel="stylesheet" type="text/css" href="../css/cms.css">
<head>
	<?php
	include '../cmsProject/header.php'
	?>
</head>
<body>
	<div id="menu">
		<?php
		include '../cmsProject/menu.php'
		?>

	<div class="center-container-aboutus">
		<h1> Our Mission</h1>
		<p> to provide a experience</p>
		<h2>About Us</h2>
		<p>Christian owners, a venue and a music shop in one place. We host musical events and music equitment expos. </p>
	</div>

	
		<div clas="row-photos-aboutus">
			<div class="column-photos"><img src="../../img/daniel-wirtz-368992.jpg" height="250" width="500"></div>
			<div class="column-photos-about-us"><img src="../../img/marcus-neto-96651.jpg" height="250" width="500"></div>
			<div class="column-photos-about-us"><img src="../../img/gabriel-gurrola-57448.jpg" height="250" width="500">
		</div>
	

	</div>
	<div id="footer">
		<?php
		include '../cmsProject/footer.php'
		?>
	</div>
</body>
</html>