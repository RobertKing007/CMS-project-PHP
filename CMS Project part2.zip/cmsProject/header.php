<?php
ob_start();
?>

<head>
	<meta  charset="utf-8">
	<meta name="description" content="CMS Webapp">
  	<meta name="keywords" content="HTML,CSS,XML,PHP, liberty university">
 	<meta name="author" content="Robert King">
  	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  	<title>CMS Web App</title>
</head>

