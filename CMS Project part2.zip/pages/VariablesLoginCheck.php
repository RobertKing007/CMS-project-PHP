<?php
ob_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<link rel="stylesheet" type="text/css" href="../css/Variables.css">
<head>
	
</head>
<body>
	<div id="menu">
		
	</div>
	<div class="centerContaier">
	<form action="../pages/VariablesLogin.php" method="post">
		Username:<input type="text" name="username"><br>
		Password:<input type="password" name="password"><br>
		<input type="submit" name="submit">
	</form>	

	<div id="footer">
		
	</div>
</body>
</html>