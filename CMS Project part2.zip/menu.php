<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta  charset="utf-8">
	<meta name="description" content="menu bar">
  	<meta name="keywords" content="HTML,CSS,XML,PHP, liberty university">
 	<meta name="author" content="Robert King">
  	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  	<title>My First PHP Webapp</title>
</head>
<body>

	<a href="../intro.php">Assingment 1</a>
	<a href="../Variables.php">Assingment 2</a>
	<a href="../webForm.php">Assingment 3</a>
	<a href=".php">Assingment 4</a>
	<a href=".php">Assingment 5</a>
	<a href=".php">Assingment 6</a>
	

</body>

<link rel="stylesheet" type="text/css" href="../css/index.css">

</html>